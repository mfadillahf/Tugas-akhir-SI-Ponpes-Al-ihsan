

<?php $__env->startSection('title', 'Tambah Infaq'); ?>

<?php $__env->startSection('vendor-style'); ?>
<?php echo app('Illuminate\Foundation\Vite')([
'resources/assets/vendor/libs/bootstrap-select/bootstrap-select.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/tagify/tagify.scss',
'resources/assets/vendor/libs/@form-validation/form-validation.scss'
]); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-select/bootstrap-select.js',
'resources/assets/vendor/libs/moment/moment.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/tagify/tagify.js',
'resources/assets/vendor/libs/@form-validation/popular.js',
'resources/assets/vendor/libs/@form-validation/bootstrap5.js',
'resources/assets/vendor/libs/@form-validation/auto-focus.js'
]); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/assets/js/form-validation-infaq.js']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main class="app-main">
    <div class="col-12">
        <div class="card shadow-sm">
            <div class="card-body">
                
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>

                <form action="<?php echo e(route('infaq.store')); ?>" method="POST" class="row g-4 needs-validation" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="col-12">
                        <h4 class="fw-bold">Tambah Infaq</h4>
                    </div>

                    
                    <div class="col-12">
                        <h6>1. Informasi Infaq</h6>
                        <hr />
                    </div>

                    <div class="col-md-6">
                        <div class="form-floating form-floating-outline">
                            <input type="number" name="nominal" id="nominal" class="form-control" placeholder="Nominal" value="<?php echo e(old('nominal')); ?>" required>
                            <label for="nominal">Nominal</label>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-floating form-floating-outline">
                            <input type="date" name="tanggal" id="tanggal" class="form-control" value="<?php echo e(old('tanggal', now()->format('Y-m-d'))); ?>" required>
                            <label for="tanggal">Tanggal</label>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="form-floating form-floating-outline">
                            <input type="text" name="keterangan" id="keterangan" class="form-control" placeholder="Keterangan" value="<?php echo e(old('keterangan')); ?>">
                            <label for="keterangan">Keterangan</label>
                        </div>
                    </div>

                    <div class="col-md-12 mb-3">
                        <label for="foto" class="form-label">Foto Bukti Transfer</label>
                        <input type="file" class="form-control" name="foto" accept="image/*">
                    </div>

                    <!-- Tampilan gambar QRIS yang bisa diklik -->
                    <div class="mb-3 text-center">
                        <label class="form-label d-block">Scan QRIS untuk Infaq</label>
                        <img src="<?php echo e(asset('images/qris.jpg')); ?>"
                            alt="QRIS Infaq"
                            style="max-width: 300px; cursor: pointer;"
                            class="img-fluid rounded shadow-sm"
                            data-bs-toggle="modal"
                            data-bs-target="#qrisModal">
                    </div>

                    
                    <div class="col-12 d-flex justify-content-end gap-2 mt-3">
                        <a href="<?php echo e(route('infaq.index')); ?>" class="btn btn-secondary">← Kembali</a>
                        <button type="submit" class="btn btn-primary">Lanjut</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</main>

<!-- Modal Bootstrap untuk menampilkan QRIS besar -->
<div class="modal fade" id="qrisModal" tabindex="-1" aria-labelledby="qrisModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content bg-light">
            <div class="modal-header border-0">
                <h5 class="modal-title" id="qrisModalLabel">QRIS Infaq</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
            </div>
            <div class="modal-body text-center">
                <img src="<?php echo e(asset('images/qris.jpg')); ?>" alt="QRIS Besar" class="img-fluid rounded shadow">
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layoutMaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Kuliah\TA\Project TA\web\SI-Ponpes-Al-ihsan 2\resources\views/infaq/infaqCreate.blade.php ENDPATH**/ ?>