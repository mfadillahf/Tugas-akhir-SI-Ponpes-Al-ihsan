

<?php $__env->startSection('title', 'Edit Agenda'); ?>

<?php $__env->startSection('vendor-style'); ?>
<?php echo app('Illuminate\Foundation\Vite')([
    'resources/assets/vendor/libs/bootstrap-select/bootstrap-select.scss',
    'resources/assets/vendor/libs/select2/select2.scss',
    'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
    'resources/assets/vendor/libs/tagify/tagify.scss',
    'resources/assets/vendor/libs/@form-validation/form-validation.scss'
]); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')([
    'resources/assets/vendor/libs/select2/select2.js',
    'resources/assets/vendor/libs/bootstrap-select/bootstrap-select.js',
    'resources/assets/vendor/libs/moment/moment.js',
    'resources/assets/vendor/libs/flatpickr/flatpickr.js',
    'resources/assets/vendor/libs/tagify/tagify.js',
    'resources/assets/vendor/libs/@form-validation/popular.js',
    'resources/assets/vendor/libs/@form-validation/bootstrap5.js',
    'resources/assets/vendor/libs/@form-validation/auto-focus.js'
]); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/assets/js/form-validation-agenda.js']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main class="app-main">
    <div class="col-12">
        <div class="card shadow-sm">
            <div class="card-body">

                
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>

                <form id="formAgendaEdit" action="<?php echo e(route('agenda.update', $agenda->id_agenda)); ?>" method="POST" enctype="multipart/form-data" class="row g-4 needs-validation">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="col-12">
                        <h4 class="fw-bold">Edit Agenda</h4>
                    </div>

                    
                    <div class="col-12">
                        <h6>1. Kategori Agenda</h6>
                        <hr />
                    </div>

                    <div class="col-md-6">
                        <div class="form-floating form-floating-outline">
                            <select name="id_jenis_agenda" id="id_jenis_agenda" class="form-select" required>
                                <option value="" disabled>-- Pilih Jenis Agenda --</option>
                                <?php $__currentLoopData = $jenisAgenda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ja): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($ja->id_jenis_agenda); ?>" <?php echo e(old('id_jenis_agenda', $agenda->id_jenis_agenda) == $ja->id_jenis_agenda ? 'selected' : ''); ?>>
                                        <?php echo e($ja->jenis_agenda); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <label for="id_jenis_agenda">Jenis Agenda</label>
                        </div>
                    </div>

                    
                    <div class="col-12">
                        <h6 class="mt-2">2. Informasi Agenda</h6>
                        <hr />
                    </div>

                    <div class="col-md-6">
                        <div class="form-floating form-floating-outline">
                            <input type="text" id="judul" name="judul" class="form-control" placeholder="Judul" value="<?php echo e(old('judul', $agenda->judul)); ?>" required>
                            <label for="judul">Judul</label>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-floating form-floating-outline">
                            <textarea class="form-control" name="deskripsi" id="deskripsi" placeholder="Deskripsi" style="height: 58px;" required><?php echo e(old('deskripsi', $agenda->deskripsi)); ?></textarea>
                            <label for="deskripsi">Deskripsi</label>
                        </div>
                    </div>

                    
                    <div class="col-12">
                        <h6 class="mt-2">3. Jadwal</h6>
                        <hr />
                    </div>

                    <div class="col-md-6">
                        <div class="form-floating form-floating-outline">
                            <input type="date" name="tanggal_mulai" id="tanggal_mulai" class="form-control" value="<?php echo e(old('tanggal_mulai', $agenda->tanggal_mulai)); ?>" required>
                            <label for="tanggal_mulai">Tanggal Mulai</label>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-floating form-floating-outline">
                            <input type="date" name="tanggal_akhir" id="tanggal_akhir" class="form-control" value="<?php echo e(old('tanggal_akhir', $agenda->tanggal_akhir)); ?>" required>
                            <label for="tanggal_akhir">Tanggal Akhir</label>
                        </div>
                    </div>

                    
                    <div class="col-12 d-flex justify-content-end gap-2 mt-3">
                        <a href="<?php echo e(route('agenda.index')); ?>" class="btn btn-secondary">← Kembali</a>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </form>

            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutMaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Kuliah\TA\Project TA\web\SI-Ponpes-Al-ihsan 2\resources\views/Agenda_Ponpes/AgendaEdit.blade.php ENDPATH**/ ?>