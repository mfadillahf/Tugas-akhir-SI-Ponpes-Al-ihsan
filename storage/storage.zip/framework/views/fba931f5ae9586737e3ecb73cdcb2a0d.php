<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ponpes Al-Ihsan Banjarmasin Tengah</title>
    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('studypress/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('studypress/css/style-main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('studypress/css/responsive.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('studypress/css/animate.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('studypress/css/javascript-plugins-bundle.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('studypress/js/menuzord/css/menuzord.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('studypress/css/colors/theme-skin-color-set1.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('studypress/css/menuzord-skins/menuzord-rounded-boxed.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('studypress/js/revolution-slider/css/rs6.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('studypress/js/revolution-slider/extra-rev-slider1.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('studypress/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('studypress/css/owl.theme.default.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('studypress/css/lightgallery.min.css')); ?>">

    <?php echo $__env->yieldPushContent('styles'); ?>
    <!-- Tambahkan stylesheet lainnya sesuai kebutuhan -->
    </head>
    <body class="tm-container-1340px has-side-panel side-panel-right">

    <!-- Preloader -->
    <?php echo $__env->make('partials.preloader', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div id="wrapper" class="clearfix">
    <!-- Header -->
    <?php echo $__env->make('partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="main-content-area">
            <?php echo $__env->yieldContent('content'); ?>
        </div>

    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Scripts -->
    <script src="<?php echo e(asset('studypress/js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('studypress/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('studypress/js/owl.carousel2.thumbs.min.js')); ?>"></script>
    <script src="<?php echo e(asset('studypress/js/owl-init.js')); ?>"></script>
    <script src="<?php echo e(asset('studypress/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('studypress/js/bootstrap.min.js')); ?>"></script>
    <!-- plugin bundle -->
    <script src="<?php echo e(asset('studypress/js/javascript-plugins-bundle.js')); ?>"></script>
    <!-- menu -->
    <script src="<?php echo e(asset('studypress/js/menuzord/js/menuzord.js')); ?>"></script>
    <!-- revolution slider -->
    <script src="<?php echo e(asset('studypress/js/revolution-slider/js/revolution.tools.min.js')); ?>"></script>
    <script src="<?php echo e(asset('studypress/js/revolution-slider/js/rs6.min.js')); ?>"></script>
    <script src="<?php echo e(asset('studypress/js/revolution-slider/extra-rev-slider1.js')); ?>"></script>
    <script src="<?php echo e(asset('studypress/js/custom.js')); ?>"></script>
    <script src="<?php echo e(asset('studypress/js/custom-script.js')); ?>"></script>
    <script src="<?php echo e(asset('studypress/js/lightgallery-all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('studypress/js/lightgallery.js')); ?>"></script>

    <script>
        $(document).ready(function () {
        $('#top-primary-nav .menuzord-menu li a, #top-primary-nav-clone .menuzord-menu li a').on('click', function () {
            if ($(window).width() <= 1199) {
            $('.menuzord-responsive .showhide').trigger('click');
            }
        });
        });
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH D:\Kuliah\TA\Project TA\web\SI-Ponpes-Al-ihsan 2\resources\views/layouts/landing.blade.php ENDPATH**/ ?>