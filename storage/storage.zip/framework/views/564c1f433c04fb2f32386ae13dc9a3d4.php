

<?php $__env->startSection('title', 'Edit Profil Donatur'); ?>

<!-- Vendor Styles -->
<?php $__env->startSection('vendor-style'); ?>
<?php echo app('Illuminate\Foundation\Vite')([
    'resources/assets/vendor/libs/bootstrap-select/bootstrap-select.scss',
    'resources/assets/vendor/libs/select2/select2.scss',
    'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
    'resources/assets/vendor/libs/tagify/tagify.scss',
    'resources/assets/vendor/libs/@form-validation/form-validation.scss'
]); ?>
<?php $__env->stopSection(); ?>

<!-- Vendor Scripts -->
<?php $__env->startSection('vendor-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')([
    'resources/assets/vendor/libs/select2/select2.js',
    'resources/assets/vendor/libs/bootstrap-select/bootstrap-select.js',
    'resources/assets/vendor/libs/moment/moment.js',
    'resources/assets/vendor/libs/flatpickr/flatpickr.js',
    'resources/assets/vendor/libs/tagify/tagify.js',
    'resources/assets/vendor/libs/@form-validation/popular.js',
    'resources/assets/vendor/libs/@form-validation/bootstrap5.js',
    'resources/assets/vendor/libs/@form-validation/auto-focus.js'
]); ?>
<?php $__env->stopSection(); ?>

<!-- Page Scripts -->
<?php $__env->startSection('page-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/assets/js/pages-profile-donatur-edit.js']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card mb-6">
        <div class="card-header">
            <h5 class="card-title mb-0">Edit Profil Donatur</h5>
        </div>
        <div class="card-body pt-0">
            
            <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            </div>
            <?php endif; ?>

    <form id="formAccountSettings" method="POST" action="<?php echo e(route('profile.update')); ?>" enctype="multipart/form-data" class="row g-4 needs-validation">
        <?php echo csrf_field(); ?>
        <div class="row mt-1 g-5">
            <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                    <input type="text" class="form-control" id="username" name="username" value="<?php echo e(old('username', auth()->user()->username)); ?>" required />
                    <label for="username">Username</label>
                </div>
                </div>

            <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                    <input type="password" class="form-control" id="password" name="password" placeholder="Kosongkan jika tidak ingin ubah" />
                    <label for="password">Password Baru</label>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                    <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" />
                    <label for="password_confirmation">Konfirmasi Password</label>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                    <input type="text" class="form-control" id="nama" name="nama" value="<?php echo e(old('nama', $profile->nama)); ?>" required />
                    <label for="nama">Nama</label>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                    <input type="text" class="form-control" id="no_telepon" name="no_telepon" value="<?php echo e(old('no_telepon', $profile->no_telepon)); ?>" required />
                    <label for="no_telepon">No Telepon</label>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                    <input type="email" class="form-control" id="email" name="email" value="<?php echo e(old('email', $profile->email)); ?>" />
                    <label for="email">Email</label>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                    <textarea class="form-control h-px-50" placeholder="Alamat lengkap" id="alamat" name="alamat" style="height: 100px" required><?php echo e(old('alamat', $profile->alamat)); ?></textarea>
                    <label for="alamat">Alamat</label>
                </div>
                </div>
        </div>

            <div class="mt-6 d-flex justify-content-end gap-2">
                <a href="<?php echo e(route('profile.show')); ?>" class="btn btn-secondary">← Kembali</a>
                <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
            </div>
        </form>
    </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutMaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Kuliah\TA\Project TA\web\SI-Ponpes-Al-ihsan 2\resources\views/Profile/ProfileDonaturEdit.blade.php ENDPATH**/ ?>