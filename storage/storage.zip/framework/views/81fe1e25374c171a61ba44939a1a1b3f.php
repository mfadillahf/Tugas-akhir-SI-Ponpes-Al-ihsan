

<?php $__env->startSection('title', 'Kalender'); ?>

<?php $__env->startSection('content'); ?>
<!-- Section: Page Title -->
<section class="page-title layer-overlay overlay-dark-9 section-typo-light bg-img-center" style="padding-top: 120px;" data-tm-bg-img="<?php echo e(asset('LandingPage/studypress/images/bg/bg1.jpg')); ?>">
    <div class="container pt-50 pb-50">
        <div class="section-content">
            <div class="row align-items-center">
                <div class="col-md-6 text-center text-md-start">
                    <h2 class="title">Kalender</h2>
                </div>
                <div class="col-md-6 text-end">
                    <nav class="breadcrumbs" role="navigation" aria-label="Breadcrumbs">
                        <div class="breadcrumbs">
                            <span><a href="<?php echo e(route('landing')); ?>">Beranda</a></span>
                            <span><i class="fa fa-angle-right mx-2"></i></span>
                            <span class="active">Kalender</span>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Section: Kalender -->
<section class="py-5">
    <div class="container">
        <div class="section-content">
            <div class="row">
                <div class="col-md-12">
                    <div id="full-event-calendar"></div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<!-- FullCalendar CSS CDN -->
<link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/index.global.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<!-- FullCalendar JS CDN -->
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/index.global.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var calendarEl = document.getElementById('full-event-calendar');
        var calendar = new FullCalendar.Calendar(calendarEl, {
            initialView: 'dayGridMonth',
            locale: 'id',
            height: 'auto',
            headerToolbar: {
                left: 'prev,next today',
                center: 'title',
                right: 'dayGridMonth,timeGridWeek,listWeek'
            },
            events: <?php echo json_encode($events, 15, 512) ?>
        });
        calendar.render();
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.landing', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Kuliah\TA\Project TA\web\SI-Ponpes-Al-ihsan 2\resources\views/LandingPage/Kalender.blade.php ENDPATH**/ ?>