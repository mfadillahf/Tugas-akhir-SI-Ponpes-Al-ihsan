

<?php $__env->startSection('title', 'User Profile - Santri'); ?>

<!-- Vendor Styles -->
<?php $__env->startSection('vendor-style'); ?>
<?php echo app('Illuminate\Foundation\Vite')([
    'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
    'resources/assets/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.scss',
    'resources/assets/vendor/libs/datatables-checkboxes-jquery/datatables.checkboxes.scss',
    'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss'
]); ?>
<?php $__env->stopSection(); ?>

<!-- Page Styles -->
<?php $__env->startSection('page-style'); ?>
<?php echo app('Illuminate\Foundation\Vite')([
    'resources/assets/vendor/scss/pages/page-profile.scss',
    'resources/assets/vendor/libs/sweetalert2/sweetalert2.js'
]); ?>
<?php $__env->stopSection(); ?>

<!-- Vendor Scripts -->
<?php $__env->startSection('vendor-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js']); ?>
<?php $__env->stopSection(); ?>

<!-- Page Scripts -->
<?php $__env->startSection('page-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/assets/js/pages-profile-santri.js']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<meta name="flash-success" content="<?php echo e(session('success')); ?>">
<meta name="flash-error" content="<?php echo e(session('error')); ?>">

<!-- Header -->
<div class="row">
    <div class="col-12">
        <div class="card mb-6">
        <div class="user-profile-header-banner">
            <img src="<?php echo e(asset('assets/img/pages/profile-banner.png')); ?>" alt="Banner image" class="rounded-top">
        </div>
        <div class="user-profile-header d-flex flex-column flex-sm-row text-sm-start text-center mb-5">
            <div class="flex-shrink-0 mt-n2 mx-sm-0 mx-auto">
            <img src="<?php echo e(asset('assets/img/avatars/1.png')); ?>" alt="user image" class="d-block h-auto ms-0 ms-sm-5 rounded-4 user-profile-img">
            </div>
            <div class="flex-grow-1 mt-4 mt-sm-12">
            <div class="d-flex align-items-md-end align-items-sm-start align-items-center justify-content-md-between justify-content-start mx-5 flex-md-row flex-column gap-6">
                <div class="user-profile-info">
                <h4 class="mb-2"><?php echo e($profile->nama_lengkap); ?></h4>
                <span class="badge bg-label-info">Santri</span>
                </div>
            </div>
            </div>
        </div>
        </div>
    </div>
</div>
<!--/ Header -->

<!-- User Profile Content -->
<div class="row">
    <div class="col-12">
        <!-- About User -->
        <div class="card mb-6">
        <div class="card-body">
            <small class="card-text text-uppercase text-muted small">Tentang</small>
            <div class="row g-4 my-2">
            <div class="col-md-6 d-flex align-items-center">
                <i class="ri-user-3-line ri-24px me-2 text-muted"></i>
                <span><strong>Nama Lengkap:</strong> <?php echo e($profile->nama_lengkap); ?></span>
            </div>

            <div class="col-md-6 d-flex align-items-center">
                <i class="ri-account-circle-line ri-24px me-2 text-muted"></i>
                <span><strong>Username:</strong> <?php echo e($profile->user->username ?? '-'); ?></span>
            </div>

            <div class="col-md-6 d-flex align-items-center">
                <i class="ri-user-smile-line ri-24px me-2 text-muted"></i>
                <span><strong>Nama Panggilan:</strong> <?php echo e($profile->nama_panggil); ?></span>
            </div>

            <div class="col-md-6 d-flex align-items-center">
                <i class="ri-calendar-line ri-24px me-2 text-muted"></i>
                <span><strong>Tanggal Lahir:</strong> <?php echo e($profile->tanggal_lahir); ?></span>
            </div>

            <div class="col-md-6 d-flex align-items-center">
                <i class="ri-user-line ri-24px me-2 text-muted"></i>
                <span><strong>Jenis Kelamin:</strong> <?php echo e($profile->jenis_kelamin); ?></span>
            </div>

            <div class="col-md-6 d-flex align-items-center">
                <i class="ri-book-2-line ri-24px me-2 text-muted"></i>
                <span><strong>Pendidikan Asal:</strong> <?php echo e($profile->pendidikan_asal); ?></span>
            </div>

            <div class="col-md-6 d-flex align-items-center">
                <i class="ri-map-pin-line ri-24px me-2 text-muted"></i>
                <span><strong>Alamat:</strong> <?php echo e($profile->alamat); ?></span>
            </div>

            <div class="col-md-6 d-flex align-items-center">
                <i class="ri-phone-line ri-24px me-2 text-muted"></i>
                <span><strong>No Telepon:</strong> <?php echo e($profile->no_telepon); ?></span>
            </div>

            <div class="col-md-6 d-flex align-items-center">
                <i class="ri-mail-line ri-24px me-2 text-muted"></i>
                <span><strong>Email:</strong> <?php echo e($profile->email); ?></span>
            </div>

            <div class="col-md-6 d-flex align-items-center">
                <i class="ri-user-2-line ri-24px me-2 text-muted"></i>
                <span><strong>Nama Ayah:</strong> <?php echo e($profile->nama_ayah); ?></span>
            </div>

            <div class="col-md-6 d-flex align-items-center">
                <i class="ri-briefcase-line ri-24px me-2 text-muted"></i>
                <span><strong>Pekerjaan Ayah:</strong> <?php echo e($profile->pekerjaan_ayah); ?></span>
            </div>

            <div class="col-md-6 d-flex align-items-center">
                <i class="ri-phone-line ri-24px me-2 text-muted"></i>
                <span><strong>No HP Ayah:</strong> <?php echo e($profile->no_hp_ayah); ?></span>
            </div>

            <div class="col-md-6 d-flex align-items-center">
                <i class="ri-user-2-line ri-24px me-2 text-muted"></i>
                <span><strong>Nama Ibu:</strong> <?php echo e($profile->nama_ibu); ?></span>
            </div>

            <div class="col-md-6 d-flex align-items-center">
                <i class="ri-briefcase-line ri-24px me-2 text-muted"></i>
                <span><strong>Pekerjaan Ibu:</strong> <?php echo e($profile->pekerjaan_ibu); ?></span>
            </div>

            <div class="col-md-6 d-flex align-items-center">
                <i class="ri-phone-line ri-24px me-2 text-muted"></i>
                <span><strong>No HP Ibu:</strong> <?php echo e($profile->no_hp_ibu); ?></span>
            </div>
            </div>

        <div class="d-flex justify-content-end mt-3">
            <a href="<?php echo e(route('profile.edit')); ?>" class="btn btn-primary">Edit Profil</a>
            </div>
        </div>
    </div>
    <!--/ About User -->
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutMaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Kuliah\TA\Project TA\web\SI-Ponpes-Al-ihsan 2\resources\views/profile/profilesantri.blade.php ENDPATH**/ ?>