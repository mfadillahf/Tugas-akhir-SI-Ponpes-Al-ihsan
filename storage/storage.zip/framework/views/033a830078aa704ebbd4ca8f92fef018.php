

<?php $__env->startSection('title', 'User Profile - Admin'); ?>

<!-- Vendor Styles -->
<?php $__env->startSection('vendor-style'); ?>
<?php echo app('Illuminate\Foundation\Vite')([
  'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
  'resources/assets/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.scss',
  'resources/assets/vendor/libs/datatables-checkboxes-jquery/datatables.checkboxes.scss',
  'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss'
]); ?>
<?php $__env->stopSection(); ?>

<!-- Page Styles -->
<?php $__env->startSection('page-style'); ?>
<?php echo app('Illuminate\Foundation\Vite')([
    'resources/assets/vendor/scss/pages/page-profile.scss',
    'resources/assets/vendor/libs/sweetalert2/sweetalert2.js'
]); ?>
<?php $__env->stopSection(); ?>

<!-- Vendor Scripts -->
<?php $__env->startSection('vendor-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js']); ?>
<?php $__env->stopSection(); ?>

<!-- Page Scripts -->
<?php $__env->startSection('page-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/assets/js/pages-profile-admin.js']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<meta name="flash-success" content="<?php echo e(session('success')); ?>">
<meta name="flash-error" content="<?php echo e(session('error')); ?>">
<!-- Header -->
<div class="row">
    <div class="col-12">
        <div class="card mb-6">
        <div class="user-profile-header-banner">
            <img src="<?php echo e(asset('assets/img/pages/profile-banner.png')); ?>" alt="Banner image" class="rounded-top">
        </div>
        <div class="user-profile-header d-flex flex-column flex-sm-row text-sm-start text-center mb-5">
            <div class="flex-shrink-0 mt-n2 mx-sm-0 mx-auto">
            <img src="<?php echo e(asset('assets/img/avatars/1.png')); ?>" alt="user image" class="d-block h-auto ms-0 ms-sm-5 rounded-4 user-profile-img">
            </div>
            <div class="flex-grow-1 mt-4 mt-sm-12">
            <div class="d-flex align-items-md-end align-items-sm-start align-items-center justify-content-md-between justify-content-start mx-5 flex-md-row flex-column gap-6">
                <div class="user-profile-info">
                <h4 class="mb-2"><?php echo e($profile->name ?? 'Admin'); ?></h4>
                <span class="badge bg-label-primary">Admin</span>
                </div>
            </div>
            </div>
        </div>
        </div>
    </div>
</div>
<!--/ Header -->

<!-- User Profile Content -->
<div class="row">
    <div class="col-12">
        <!-- About User -->
        <div class="card mb-6">
        <div class="card-body">
            <small class="card-text text-uppercase text-muted small">Tentang</small>
            <ul class="list-unstyled my-3 py-1">
            <li class="d-flex align-items-center mb-4"><i class="ri-user-3-line ri-24px"></i><span class="fw-medium mx-2">Username:</span> <span><?php echo e($profile->username); ?></span></li>
            <li class="d-flex align-items-center mb-4"><i class="ri-star-smile-line ri-24px"></i><span class="fw-medium mx-2">Role:</span> <span><?php echo e($profile->roles->pluck('name')->first() ?? 'Admin'); ?></span></li>
            </ul>

            <div class="d-flex justify-content-end mt-3">
            <a href="<?php echo e(route('profile.edit')); ?>" class="btn btn-primary">Edit / ganti password</a>
            </div>
        </div>
        </div>
        <!--/ About User -->
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutMaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Kuliah\TA\Project TA\web\SI-Ponpes-Al-ihsan 2\resources\views/profile/profileadmin.blade.php ENDPATH**/ ?>