<?php
$containerFooter = ($configData['contentLayout'] === 'compact') ? 'container-xxl' : 'container-fluid';
?>

<!-- Footer -->
<footer class="content-footer footer bg-footer-theme">
  <div class="<?php echo e($containerFooter); ?>">
    <div class="footer-container d-flex align-items-center justify-content-between py-4 flex-md-row flex-column">
      <div class="text-body mb-2 mb-md-0">
        © <script>document.write(new Date().getFullYear())</script>,
        Ponpes Al-Ihsan Banjarmasin 
        
        
      </div>
      
    </div>
  </div>
</footer>
<!--/ Footer -->
<?php /**PATH D:\Kuliah\TA\Project TA\web\SI-Ponpes-Al-ihsan 2\resources\views/layouts/sections/footer/footer.blade.php ENDPATH**/ ?>