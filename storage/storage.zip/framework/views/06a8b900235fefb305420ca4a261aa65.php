

<?php $__env->startSection('title', 'Tambah Hapalan Santri'); ?>

<?php $__env->startSection('vendor-style'); ?>
<?php echo app('Illuminate\Foundation\Vite')([
    'resources/assets/vendor/libs/bootstrap-select/bootstrap-select.scss',
    'resources/assets/vendor/libs/select2/select2.scss',
    'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
    'resources/assets/vendor/libs/tagify/tagify.scss',
    'resources/assets/vendor/libs/@form-validation/form-validation.scss'
]); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')([
    'resources/assets/vendor/libs/select2/select2.js',
    'resources/assets/vendor/libs/bootstrap-select/bootstrap-select.js',
    'resources/assets/vendor/libs/moment/moment.js',
    'resources/assets/vendor/libs/flatpickr/flatpickr.js',
    'resources/assets/vendor/libs/tagify/tagify.js',
    'resources/assets/vendor/libs/@form-validation/popular.js',
    'resources/assets/vendor/libs/@form-validation/bootstrap5.js',
    'resources/assets/vendor/libs/@form-validation/auto-focus.js'
]); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/assets/js/form-validation-hapalan.js']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main class="app-main">
    <div class="col-12">
        <div class="card shadow-sm">
            <div class="card-body">

                <?php if(session('error')): ?>
                    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

        
        <h5 class="my-4">Pilih Kelas</h5>
        <form method="GET" action="<?php echo e(route('hapalan.create')); ?>" class="row g-4 mb-4">
            <div class="col-sm-10 col-8">
                <div class="form-floating form-floating-outline position-relative">
                <select name="id_kelas" id="id_kelas" class="form-select select2" required>
                    <option value="">-- Pilih Kelas --</option>
                    <?php $__currentLoopData = $kelasList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($kelas->id_kelas); ?>" <?php echo e($id_kelas == $kelas->id_kelas ? 'selected' : ''); ?>>
                        <?php echo e($kelas->nama_kelas); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                </div>
            </div>
            <div class="col-sm-2 col-4 d-grid">
                <button type="submit" class="btn btn-primary">Tampilkan</button>
            </div>
        </form>

                
                <?php if($santris->count() > 0): ?>
                <form id="formHapalanCreate" class="row g-4 needs-validation" method="POST" action="<?php echo e(route('hapalan.store')); ?>">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="id_guru" value="<?php echo e($guru->id_guru); ?>">
                    <input type="hidden" name="id_kelas" value="<?php echo e($id_kelas); ?>">

                    <div class="col-12">
                        <h4 class="fw-bold">Tambah Hapalan Santri</h4>
                    </div>

                    
                    <div class="col-12">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead class="table-light">
                                    <tr>
                                        <th>Pilih</th>
                                        <th>Nama Santri</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $santris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $santri): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td style="width: 70px;">
                                                <input type="radio" name="id_santri" value="<?php echo e($santri->id_santri); ?>" required>
                                            </td>
                                            <td><?php echo e($santri->nama_lengkap); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    
                    <input type="hidden" name="id_guru" value="<?php echo e($guru->id_guru); ?>">

                    

                    
                    <div class="col-12 d-flex justify-content-end gap-2 mt-3">
                        <a href="<?php echo e(route('hapalan.index')); ?>" class="btn btn-secondary">← Kembali</a>
                        <button type="submit" class="btn btn-primary">Simpan Hapalan</button>
                    </div>
                </form>
                <?php endif; ?>

            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutMaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Kuliah\TA\Project TA\web\SI-Ponpes-Al-ihsan 2\resources\views/hapalan/hapalancreate.blade.php ENDPATH**/ ?>