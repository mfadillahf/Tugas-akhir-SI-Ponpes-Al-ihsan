

<?php $__env->startSection('title', 'Tambah Nilai Santri'); ?>

<!-- Vendor Styles -->
<?php $__env->startSection('vendor-style'); ?>
<?php echo app('Illuminate\Foundation\Vite')([
    'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
    'resources/assets/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.scss',
    'resources/assets/vendor/libs/datatables-checkboxes-jquery/datatables.checkboxes.scss',
    'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
    'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
    'resources/assets/vendor/libs/datatables-rowgroup-bs5/rowgroup.bootstrap5.scss',
    'resources/assets/vendor/libs/@form-validation/form-validation.scss',
    'resources/assets/vendor/libs/select2/select2.scss',
    'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss'
]); ?>
<?php $__env->stopSection(); ?>

<!-- Vendor Scripts -->
<?php $__env->startSection('vendor-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')([
    'resources/assets/vendor/libs/jquery/jquery.js',
    'resources/assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js',
    'resources/assets/vendor/libs/moment/moment.js',
    'resources/assets/vendor/libs/flatpickr/flatpickr.js',
    'resources/assets/vendor/libs/@form-validation/popular.js',
    'resources/assets/vendor/libs/@form-validation/bootstrap5.js',
    'resources/assets/vendor/libs/@form-validation/auto-focus.js',
    'resources/assets/vendor/libs/select2/select2.js',
    'resources/assets/vendor/libs/sweetalert2/sweetalert2.js'
]); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/assets/js/tables-datatables-tambah-nilai.js']); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<main class="app-main">
    <div class="app-content">
        <div class="container-fluid">

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            
            <form method="GET" action="<?php echo e(route('nilai.create')); ?>" class="card mb-4">
                <div class="card-header">
                    <h5 class="card-title mb-0">Filter Data Nilai</h5>
                </div>
                <div class="card-body border-top">
                    <div class="row g-3 align-items-end">
                        <div class="col-md-5">
                            <label for="id_kelas" class="form-label">Kelas</label>
                            <select id="id_kelas" name="id_kelas" class="form-select select2" required>
                                <option value="">Pilih Kelas</option>
                                <?php $__currentLoopData = $kelasList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($kelas->id_kelas); ?>" <?php echo e(old('id_kelas', $id_kelas) == $kelas->id_kelas ? 'selected' : ''); ?>>
                                        <?php echo e($kelas->nama_kelas); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-md-5">
                            <label for="id_mapel" class="form-label">Mapel</label>
                            <select id="id_mapel" name="id_mapel" class="form-select select2" required>
                                <option value="">Pilih Mapel</option>
                                <?php $__currentLoopData = $mapelList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mapel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($mapel->id_mapel); ?>" <?php echo e(old('id_mapel', $id_mapel) == $mapel->id_mapel ? 'selected' : ''); ?>>
                                        <?php echo e($mapel->mapel); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-md-2 d-grid">
                            <button type="submit" class="btn btn-primary w-100">Tampilkan</button>
                        </div>
                    </div>
                </div>
            </form>

            
            <?php if($santris->count() > 0): ?>
                <form method="POST" action="<?php echo e(route('nilai.store')); ?>" class="card">
                    <?php echo csrf_field(); ?>

                    
                    <input type="hidden" name="id_kelas" value="<?php echo e($id_kelas); ?>">
                    <input type="hidden" name="id_mapel" value="<?php echo e($id_mapel); ?>">

                    <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
                        <h5 class="card-title mb-0">Input Nilai Santri</h5>
                        <button type="submit" class="btn btn-success btn-sm">
                            <i class="ri-save-line"></i> Simpan Nilai
                        </button>
                    </div>

                    <div class="card-body border-top">
                        <div class="row mb-3">
                            <div class="col-md-4">
                                <label for="tahun_ajaran" class="form-label">Tahun Ajaran</label>
                                <input
                                    type="text"
                                    id="tahun_ajaran"
                                    name="tahun_ajaran"
                                    class="form-control <?php $__errorArgs = ['tahun_ajaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="2024/2025"
                                    value="<?php echo e(old('tahun_ajaran', $tahun_ajaran)); ?>"
                                    required
                                >
                            </div>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead class="table-light">
                                <tr>
                                    <th style="width: 5%;">No</th>
                                    <th>Nama Santri</th>
                                    <th style="width: 20%;">Nilai</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $santris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $santri): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($i + 1); ?></td>
                                        <td><?php echo e($santri->nama_lengkap); ?></td>
                                        <td>
                                            <input
                                                type="number"
                                                name="nilai[<?php echo e($santri->id_santri); ?>]"
                                                class="form-control <?php $__errorArgs = ['nilai.' . $santri->id_santri];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                min="0" max="100"
                                                value="<?php echo e(old('nilai.' . $santri->id_santri)); ?>"
                                                required
                                            >
                                            <?php $__errorArgs = ['nilai.' . $santri->id_santri];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layoutMaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Kuliah\TA\Project TA\web\SI-Ponpes-Al-ihsan 2\resources\views/nilai/nilaicreate.blade.php ENDPATH**/ ?>