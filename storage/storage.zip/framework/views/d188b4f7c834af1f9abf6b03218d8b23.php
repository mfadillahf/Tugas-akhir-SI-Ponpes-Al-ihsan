

<?php $__env->startSection('title', 'Tambah Guru'); ?>

<?php $__env->startSection('vendor-style'); ?>
<?php echo app('Illuminate\Foundation\Vite')([
    'resources/assets/vendor/libs/bootstrap-select/bootstrap-select.scss',
    'resources/assets/vendor/libs/select2/select2.scss',
    'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
    'resources/assets/vendor/libs/tagify/tagify.scss',
    'resources/assets/vendor/libs/@form-validation/form-validation.scss'
]); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')([
    'resources/assets/vendor/libs/select2/select2.js',
    'resources/assets/vendor/libs/bootstrap-select/bootstrap-select.js',
    'resources/assets/vendor/libs/moment/moment.js',
    'resources/assets/vendor/libs/flatpickr/flatpickr.js',
    'resources/assets/vendor/libs/tagify/tagify.js',
    'resources/assets/vendor/libs/@form-validation/popular.js',
    'resources/assets/vendor/libs/@form-validation/bootstrap5.js',
    'resources/assets/vendor/libs/@form-validation/auto-focus.js'
]); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/assets/js/form-validation-guru.js']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main class="app-main">
    <div class="col-12">
        <div class="card shadow-sm">
        <div class="card-body">
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            </div>
            <?php endif; ?>

            <form id="formGuruCreate" action="<?php echo e(route('guru.store')); ?>" method="POST" class="row g-4 needs-validation">
            <?php echo csrf_field(); ?>

            <div class="col-12">
                <h4 class="fw-bold">Tambah Guru Baru</h4>
            </div>

            
            <div class="col-12">
                <h6>1. Akun Guru</h6>
                <hr />
            </div>

            <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                <input type="text" id="username" name="username" class="form-control" placeholder="Username" value="<?php echo e(old('username')); ?>" required>
                <label for="username">Username</label>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-password-toggle">
                <div class="input-group input-group-merge">
                    <div class="form-floating form-floating-outline">
                    <input type="password" id="password" name="password" class="form-control" placeholder="Password" required>
                    <label for="password">Password</label>
                    </div>
                    <span class="input-group-text cursor-pointer"><i class="ri-eye-off-line"></i></span>
                </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-password-toggle">
                <div class="input-group input-group-merge">
                    <div class="form-floating form-floating-outline">
                    <input type="password" id="password_confirmation" name="password_confirmation" class="form-control" placeholder="Konfirmasi Password" required>
                    <label for="password_confirmation">Konfirmasi Password</label>
                    </div>
                    <span class="input-group-text cursor-pointer"><i class="ri-eye-off-line"></i></span>
                </div>
                </div>
            </div>

            
            <div class="col-12">
                <h6 class="mt-2">2. Data Pribadi</h6>
                <hr />
            </div>

            <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                <input type="text" id="nama" name="nama" class="form-control" placeholder="Nama Lengkap" value="<?php echo e(old('nama')); ?>" required>
                <label for="nama">Nama Lengkap</label>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                <input type="text" id="nip" name="nip" class="form-control" placeholder="NIP" value="<?php echo e(old('nip')); ?>">
                <label for="nip">NIP</label>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                <input type="email" id="email" name="email" class="form-control" placeholder="Email" value="<?php echo e(old('email')); ?>">
                <label for="email">Email</label>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                <input type="text" id="no_telepon" name="no_telepon" class="form-control" placeholder="No Telepon" value="<?php echo e(old('no_telepon')); ?>">
                <label for="no_telepon">No Telepon</label>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                <input type="date" id="tanggal_lahir" name="tanggal_lahir" class="form-control" value="<?php echo e(old('tanggal_lahir')); ?>" required>
                <label for="tanggal_lahir">Tanggal Lahir</label>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                <select class="form-select" id="jenis_kelamin" name="jenis_kelamin" required>
                    <option value="" disabled <?php echo e(old('jenis_kelamin') ? '' : 'selected'); ?>>-- Pilih Jenis Kelamin --</option>
                    <option value="L" <?php echo e(old('jenis_kelamin') == 'L' ? 'selected' : ''); ?>>Laki-laki</option>
                    <option value="P" <?php echo e(old('jenis_kelamin') == 'P' ? 'selected' : ''); ?>>Perempuan</option>
                </select>
                <label for="jenis_kelamin">Jenis Kelamin</label>
                </div>
            </div>

            
            <div class="col-12 d-flex justify-content-end gap-2 mt-3">
                <a href="<?php echo e(route('guru.index')); ?>" class="btn btn-secondary">← Kembali</a>
                <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
            </form>
        </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutMaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Kuliah\TA\Project TA\web\SI-Ponpes-Al-ihsan 2\resources\views/Guru/GuruCreate.blade.php ENDPATH**/ ?>