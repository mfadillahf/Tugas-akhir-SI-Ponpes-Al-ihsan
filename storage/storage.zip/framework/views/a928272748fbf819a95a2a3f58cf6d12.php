<?php use Illuminate\Support\Facades\Auth; ?>


<?php $__env->startSection('title', 'Data Infaq'); ?>

<!-- Vendor Styles -->
<?php $__env->startSection('vendor-style'); ?>
<?php echo app('Illuminate\Foundation\Vite')([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-checkboxes-jquery/datatables.checkboxes.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/datatables-rowgroup-bs5/rowgroup.bootstrap5.scss',
'resources/assets/vendor/libs/@form-validation/form-validation.scss',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss',
'resources/assets/vendor/libs/spinkit/spinkit.scss'

]); ?>
<?php $__env->stopSection(); ?>

<!-- Vendor Scripts -->
<?php $__env->startSection('vendor-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')([
'resources/assets/vendor/libs/jquery/jquery.js',
'resources/assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js',
'resources/assets/vendor/libs/moment/moment.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/@form-validation/popular.js',
'resources/assets/vendor/libs/@form-validation/bootstrap5.js',
'resources/assets/vendor/libs/@form-validation/auto-focus.js',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.js'
]); ?>
<?php $__env->stopSection(); ?>

<!-- Page Scripts -->
<?php $__env->startSection('page-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/assets/js/tables-datatables-infaq.js']); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const modalImage = document.getElementById('modalImage');

        document.querySelectorAll('img[data-bs-toggle="modal"]').forEach(img => {
            img.addEventListener('click', function() {
                const src = this.getAttribute('data-src');
                modalImage.setAttribute('src', src);
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<meta name="flash-success" content="<?php echo e(session('success')); ?>">
<meta name="flash-error" content="<?php echo e(session('error')); ?>">
<meta name="user-role" content="<?php echo e(Auth::user()->getRoleNames()->first()); ?>">

<main class="app-main">
    <div class="app-content">
        <div class="container-fluid">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
                    <h3 class="card-title mb-0">Data Infaq</h3>
                    <?php if (\Illuminate\Support\Facades\Blade::check('role', 'donatur')): ?>
                    <a href="<?php echo e(route('infaq.create')); ?>" class="btn btn-primary btn-sm">
                        <i class="ri-add-line"></i> Tambah Infaq
                    </a>
                    <?php endif; ?>
                </div>

                <div class="card-datatable table-responsive pt-0">
                    <table class="datatables-basic table table-bordered">
                        <thead class="table-light">
                            <tr>
                                <th>No</th>
                                <th>Nama Donatur</th>
                                <th>Nominal</th>
                                <th>Tanggal</th>
                                <th>Keterangan</th>
                                <th>Bukti Transfer</th>
                                <th>Status</th>
                                <?php if (\Illuminate\Support\Facades\Blade::check('role', 'admin')): ?>
                                <th>Aksi</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $infaqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $infaq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($key + 1); ?></td>
                                <td><?php echo e($infaq->donatur->nama ?? 'Tidak diketahui'); ?></td>
                                <td>Rp <?php echo e(number_format($infaq->nominal, 0, ',', '.')); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($infaq->tanggal)->format('d M Y')); ?></td>
                                <td><?php echo e($infaq->keterangan); ?></td>
                                <td>
                                    <?php if($infaq->foto): ?>
                                    <img src="<?php echo e(asset('storage/infaq/' . $infaq->foto)); ?>"
                                        alt="Foto Infaq"
                                        style="max-width: 250px; height: auto; cursor: pointer;"
                                        class="img-thumbnail"
                                        data-bs-toggle="modal"
                                        data-bs-target="#modalGambar"
                                        data-src="<?php echo e(asset('storage/infaq/' . $infaq->foto)); ?>">

                                    <?php else: ?>
                                    <span class="text-muted">Tidak ada foto</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($infaq->status === 'paid'): ?>
                                    <span class="badge bg-success">Lunas</span>
                                    <?php elseif($infaq->status === 'pending'): ?>
                                    <span class="badge bg-warning text-dark">Menunggu</span>
                                    <?php elseif($infaq->status === 'failed'): ?>
                                    <span class="badge bg-danger">Gagal</span>
                                    <?php else: ?>
                                    <span class="badge bg-secondary"><?php echo e(ucfirst($infaq->status)); ?></span>
                                    <?php endif; ?>
                                </td>
                                <?php if (\Illuminate\Support\Facades\Blade::check('role', 'admin')): ?>
                                <td>
                                    <?php if($infaq->status === 'pending'): ?>
                                    <form action="<?php echo e(route('infaq.terima', $infaq->id_infaq)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-success btn-sm btn-terima">Terima</button>
                                    </form>
                                    <form action="<?php echo e(route('infaq.tolak', $infaq->id_infaq)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-danger btn-sm btn-tolak">Tolak</button>
                                    </form>
                                    <?php else: ?>
                                    <em>-</em>
                                    <?php endif; ?>
                                </td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p>data tidak tersedia</p>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>

<!-- Modal Gambar -->
<div class="modal fade" id="modalGambar" tabindex="-1" aria-labelledby="modalGambarLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-body text-center">
                <img id="modalImage" src="" alt="Preview Gambar" class="img-fluid rounded">
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layoutMaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Kuliah\TA\Project TA\web\SI-Ponpes-Al-ihsan 2\resources\views/infaq/infaq.blade.php ENDPATH**/ ?>