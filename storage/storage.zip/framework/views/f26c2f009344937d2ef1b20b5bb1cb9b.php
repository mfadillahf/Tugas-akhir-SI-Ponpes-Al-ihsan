

<?php $__env->startSection('title', $tentang->judul); ?>

<?php $__env->startSection('content'); ?>
<!-- Section: Page Title -->
<section class="page-title layer-overlay overlay-dark-9 section-typo-light bg-img-center" style="padding-top: 120px;" data-tm-bg-img="<?php echo e(asset('LandingPage/studypress/images/bg/bg1.jpg')); ?>">
    <div class="container pt-50 pb-50">
        <div class="section-content">
        <div class="row">
          <div class="col-md-12">
                <div class="row align-items-center">
                    <div class="col-md-6 text-center text-md-start">
                    <h2 class="title">Tentang Pesantren Al-Ihsan</h2>
                    </div>
                    <div class="col-md-6 text-end">
                    <nav class="breadcrumbs" role="navigation" aria-label="Breadcrumbs">
                        <div class="breadcrumbs">
                        <span><a href="<?php echo e(route('landing')); ?>">Beranda</a></span>
                        <span><i class="fa fa-angle-right mx-2"></i></span>
                        <span class="active">Tentang</span>
                        </div>
                    </nav>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </div>
</section>

<!-- Section: Tentang -->
<section class="py-5">
  <div class="container mt-30 mb-30 pt-30 pb-30">
    <div class="row">

      <!-- Konten Tentang -->
      <div class="col-md-9">
        <div class="blog-posts single-post">
          <article class="post clearfix mb-0">
            <div class="entry-header">
              <?php if($tentang->gambar): ?>
              <div class="post-thumb thumb mb-3">
                <img src="<?php echo e(asset('storage/tentang/' . $tentang->gambar)); ?>" alt="<?php echo e($tentang->judul); ?>" class="img-responsive img-fullwidth rounded shadow">
              </div>
              <?php endif; ?>
            </div>
            <div class="entry-content">
              <div class="entry-meta d-flex no-bg no-border mt-15 pb-20">
                <div class="media-body">
                  <h3 class="entry-title pt-0 mt-0"><?php echo e($tentang->judul); ?></h3>
                </div>
              </div>
              <article class="content" style="line-height: 1.8; font-size: 1.1rem;">
                <?php echo $tentang->deskripsi; ?>

              </article>
              <div class="mt-4">
                <a href="<?php echo e(route('landing')); ?>" class="btn btn-theme-colored1 btn-sm">← Kembali ke Beranda</a>
              </div>
            </div>
          </article>
        </div>
      </div>

      <!-- Sidebar Berita Lainnya -->
      <div class="col-md-3">
        <div class="sidebar sidebar-right mt-sm-30">
          <div class="widget">
            <h4 class="widget-title widget-title-line-bottom line-bottom-theme-colored1">Berita Lainnya</h4>
            <div class="latest-posts">
              <?php $__currentLoopData = $beritaLain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <article class="post clearfix pb-0 mb-20">
                <a class="post-thumb" href="<?php echo e(route('berita.detail', $item->id_berita)); ?>">
                  <img src="<?php echo e(asset('storage/berita/' . $item->foto)); ?>" alt="<?php echo e($item->judul); ?>" style="width: 70px; height: 70px; object-fit: cover;" class="rounded shadow-sm">
                </a>
                <div class="post-right">
                  <h5 class="post-title mt-0 mb-1">
                    <a href="<?php echo e(route('berita.detail', $item->id_berita)); ?>"><?php echo e($item->judul); ?></a>
                  </h5>
                  <span class="post-date small text-muted">
                    <i class="far fa-calendar-alt me-1"></i> <?php echo e($item->created_at->format('d M Y')); ?>

                  </span>
                </div>
              </article>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.landing', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Kuliah\TA\Project TA\web\SI-Ponpes-Al-ihsan 2\resources\views/LandingPage/TentangDetail.blade.php ENDPATH**/ ?>