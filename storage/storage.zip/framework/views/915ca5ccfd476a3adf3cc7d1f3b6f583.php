

<?php $__env->startSection('title', 'Edit Santri'); ?>

<?php $__env->startSection('vendor-style'); ?>
<?php echo app('Illuminate\Foundation\Vite')([
    'resources/assets/vendor/libs/bootstrap-select/bootstrap-select.scss',
    'resources/assets/vendor/libs/select2/select2.scss',
    'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
    'resources/assets/vendor/libs/tagify/tagify.scss',
    'resources/assets/vendor/libs/@form-validation/form-validation.scss'
]); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')([
    'resources/assets/vendor/libs/select2/select2.js',
    'resources/assets/vendor/libs/bootstrap-select/bootstrap-select.js',
    'resources/assets/vendor/libs/moment/moment.js',
    'resources/assets/vendor/libs/flatpickr/flatpickr.js',
    'resources/assets/vendor/libs/tagify/tagify.js',
    'resources/assets/vendor/libs/@form-validation/popular.js',
    'resources/assets/vendor/libs/@form-validation/bootstrap5.js',
    'resources/assets/vendor/libs/@form-validation/auto-focus.js'
]); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/assets/js/form-validation-santri.js']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main class="app-main">
    <div class="col-12">
        <div class="card shadow-sm">
        <div class="card-body">

            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>

            <form id="formSantriEdit" action="<?php echo e(route('santri.update', $santri->id_santri)); ?>" method="POST" class="row g-4 needs-validation">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="col-12">
                <h4 class="fw-bold">Edit Data Santri</h4>
            </div>

            
            <div class="col-12">
                <h6>1. Akun Santri</h6>
                <hr />
            </div>

            <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                <input type="text" name="username" class="form-control" value="<?php echo e(old('username', $santri->user->username ?? '')); ?>" placeholder="Username" required>
                <label for="username">Username</label>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-password-toggle">
                <div class="input-group input-group-merge">
                    <div class="form-floating form-floating-outline">
                    <input type="password" name="password" class="form-control" placeholder="Password">
                    <label for="password">Password Baru</label>
                    </div>
                    <span class="input-group-text cursor-pointer"><i class="ri-eye-off-line"></i></span>
                </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-password-toggle">
                <div class="input-group input-group-merge">
                    <div class="form-floating form-floating-outline">
                    <input type="password" name="password_confirmation" class="form-control" placeholder="Konfirmasi Password">
                    <label for="password_confirmation">Konfirmasi Password</label>
                    </div>
                    <span class="input-group-text cursor-pointer"><i class="ri-eye-off-line"></i></span>
                </div>
                </div>
            </div>

            
            <div class="col-12">
                <h6 class="mt-2">2. Data Pribadi</h6>
                <hr />
            </div>

            <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                <input type="text" name="nama_lengkap" class="form-control" value="<?php echo e(old('nama_lengkap', $santri->nama_lengkap)); ?>" placeholder="Nama Lengkap" required>
                <label for="nama_lengkap">Nama Lengkap</label>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                <input type="text" name="nama_panggil" class="form-control" value="<?php echo e(old('nama_panggil', $santri->nama_panggil)); ?>" placeholder="Nama Panggil" required>
                <label for="nama_panggil">Nama Panggil</label>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                <input type="date" id="tanggal_lahir" name="tanggal_lahir" class="form-control" value="<?php echo e(old('tanggal_lahir', $santri->tanggal_lahir)); ?>" placeholder="Tanggal Lahir" required>
                <label for="tanggal_lahir">Tanggal Lahir</label>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                <textarea name="alamat" class="form-control" placeholder="Alamat" rows="2" required><?php echo e(old('alamat', $santri->alamat)); ?></textarea>
                <label for="alamat">Alamat</label>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                <input type="text" name="no_telepon" class="form-control" value="<?php echo e(old('no_telepon', $santri->no_telepon)); ?>" placeholder="No Telepon" required>
                <label for="no_telepon">No Telepon</label>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                <input type="email" name="email" class="form-control" value="<?php echo e(old('email', $santri->email)); ?>" placeholder="Email" required>
                <label for="email">Email</label>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                <select class="form-select" name="jenis_kelamin" required>
                    <option value="L" <?php echo e(old('jenis_kelamin', $santri->jenis_kelamin) == 'L' ? 'selected' : ''); ?>>Laki-laki</option>
                    <option value="P" <?php echo e(old('jenis_kelamin', $santri->jenis_kelamin) == 'P' ? 'selected' : ''); ?>>Perempuan</option>
                </select>
                <label for="jenis_kelamin">Jenis Kelamin</label>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                <input type="text" name="pendidikan_asal" class="form-control" value="<?php echo e(old('pendidikan_asal', $santri->pendidikan_asal)); ?>" placeholder="Pendidikan Asal" required>
                <label for="pendidikan_asal">Pendidikan Asal</label>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                <select class="form-select" name="id_kelas" required>
                    <option value="" disabled>-- Pilih Kelas --</option>
                    <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($k->id_kelas); ?>" <?php echo e(old('id_kelas', $santri->id_kelas) == $k->id_kelas ? 'selected' : ''); ?>>
                        <?php echo e($k->nama_kelas); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <label for="id_kelas">Kelas</label>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                <select class="form-select" name="status" required>
                    <option value="" disabled>-- Pilih Status --</option>
                    <option value="calon" <?php echo e(old('status', $santri->status) == 'calon' ? 'selected' : ''); ?>>Calon</option>
                    <option value="santri" <?php echo e(old('status', $santri->status) == 'santri' ? 'selected' : ''); ?>>Santri</option>
                </select>
                <label for="status">Status</label>
                </div>
            </div>

            
            <div class="col-12">
                <h6 class="mt-2">3. Data Orang Tua</h6>
                <hr />
            </div>

            <?php $__currentLoopData = [
                'ayah' => 'Ayah',
                'ibu' => 'Ibu'
            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prefix => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                <input type="text" name="nama_<?php echo e($prefix); ?>" class="form-control" value="<?php echo e(old('nama_'.$prefix, $santri->{'nama_'.$prefix})); ?>" placeholder="Nama <?php echo e($label); ?>" required>
                <label for="nama_<?php echo e($prefix); ?>">Nama <?php echo e($label); ?></label>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                <input type="text" name="pekerjaan_<?php echo e($prefix); ?>" class="form-control" value="<?php echo e(old('pekerjaan_'.$prefix, $santri->{'pekerjaan_'.$prefix})); ?>" placeholder="Pekerjaan <?php echo e($label); ?>" required>
                <label for="pekerjaan_<?php echo e($prefix); ?>">Pekerjaan <?php echo e($label); ?></label>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                <input type="text" name="no_hp_<?php echo e($prefix); ?>" class="form-control" value="<?php echo e(old('no_hp_'.$prefix, $santri->{'no_hp_'.$prefix})); ?>" placeholder="No HP <?php echo e($label); ?>" required>
                <label for="no_hp_<?php echo e($prefix); ?>">No HP <?php echo e($label); ?></label>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="col-12 d-flex justify-content-end gap-2 mt-3">
                <a href="<?php echo e(route('santri.index')); ?>" class="btn btn-secondary">← Kembali</a>
                <button type="submit" class="btn btn-primary">Update</button>
            </div>
            </form>
        </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutMaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Kuliah\TA\Project TA\web\SI-Ponpes-Al-ihsan 2\resources\views/Santri/SantriEdit.blade.php ENDPATH**/ ?>