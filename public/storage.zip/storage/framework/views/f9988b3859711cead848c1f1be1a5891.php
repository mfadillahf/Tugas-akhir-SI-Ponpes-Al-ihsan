<!-- Preloader -->
<div id="preloader">
    <div id="spinner">
        <div class="preloader-dot-loading">
        <div class="cssload-loading"><i></i><i></i><i></i><i></i></div>
        </div>
    </div>
    
</div><?php /**PATH D:\Kuliah\TA\Project TA\web\SI-Ponpes-Al-ihsan 2\resources\views/partials/preloader.blade.php ENDPATH**/ ?>