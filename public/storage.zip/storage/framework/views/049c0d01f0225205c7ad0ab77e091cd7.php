

<?php $__env->startSection('title', 'Edit Profil Santri'); ?>

<!-- Vendor Styles -->
<?php $__env->startSection('vendor-style'); ?>
<?php echo app('Illuminate\Foundation\Vite')([
    'resources/assets/vendor/libs/bootstrap-select/bootstrap-select.scss',
    'resources/assets/vendor/libs/select2/select2.scss',
    'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
    'resources/assets/vendor/libs/tagify/tagify.scss',
    'resources/assets/vendor/libs/@form-validation/form-validation.scss'
]); ?>
<?php $__env->stopSection(); ?>

<!-- Vendor Scripts -->
<?php $__env->startSection('vendor-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')([
    'resources/assets/vendor/libs/select2/select2.js',
    'resources/assets/vendor/libs/bootstrap-select/bootstrap-select.js',
    'resources/assets/vendor/libs/moment/moment.js',
    'resources/assets/vendor/libs/flatpickr/flatpickr.js',
    'resources/assets/vendor/libs/tagify/tagify.js',
    'resources/assets/vendor/libs/@form-validation/popular.js',
    'resources/assets/vendor/libs/@form-validation/bootstrap5.js',
    'resources/assets/vendor/libs/@form-validation/auto-focus.js'
]); ?>
<?php $__env->stopSection(); ?>

<!-- Page Scripts -->
<?php $__env->startSection('page-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/assets/js/pages-profile-santri-edit.js']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card mb-6">
        <div class="card-header">
            <h5 class="card-title mb-0">Edit Profil Santri</h5>
        </div>
        <div class="card-body pt-0">
        <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>

        <form id="formAccountSettings" action="<?php echo e(route('profile.update')); ?>" method="POST" enctype="multipart/form-data" class="row g-4 needs-validation">
            <?php echo csrf_field(); ?>
            <div class="row mt-1 g-5">
                <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                    <input type="text" class="form-control" name="username" id="username" value="<?php echo e(old('username', auth()->user()->username)); ?>" required>
                    <label for="username">Username</label>
                </div>
                </div>
                <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                    <input type="password" class="form-control" name="password" id="password" placeholder="Kosongkan jika tidak ingin ubah">
                    <label for="password">Password Baru</label>
                </div>
                </div>
                <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                    <input type="password" class="form-control" name="password_confirmation" id="password_confirmation">
                    <label for="password_confirmation">Konfirmasi Password</label>
                </div>
                </div>
                <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                    <input type="text" class="form-control" name="nama_lengkap" id="nama_lengkap" value="<?php echo e(old('nama_lengkap', $profile->nama_lengkap)); ?>" required>
                    <label for="nama_lengkap">Nama Lengkap</label>
                </div>
                </div>
                <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                    <input type="text" class="form-control" name="nama_panggil" id="nama_panggil" value="<?php echo e(old('nama_panggil', $profile->nama_panggil)); ?>" required>
                    <label for="nama_panggil">Nama Panggilan</label>
                </div>
                </div>
                <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                    <input type="date" class="form-control" name="tanggal_lahir" id="tanggal_lahir" value="<?php echo e(old('tanggal_lahir', $profile->tanggal_lahir)); ?>" required>
                    <label for="tanggal_lahir">Tanggal Lahir</label>
                </div>
                </div>
                <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                    <select class="form-select" name="jenis_kelamin" id="jenis_kelamin" required>
                    <option value="Laki-laki" <?php echo e(old('jenis_kelamin', $profile->jenis_kelamin) == 'Laki-laki' ? 'selected' : ''); ?>>Laki-laki</option>
                    <option value="Perempuan" <?php echo e(old('jenis_kelamin', $profile->jenis_kelamin) == 'Perempuan' ? 'selected' : ''); ?>>Perempuan</option>
                    </select>
                    <label for="jenis_kelamin">Jenis Kelamin</label>
                </div>
                </div>
                <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                    <input type="text" class="form-control" name="pendidikan_asal" id="pendidikan_asal" value="<?php echo e(old('pendidikan_asal', $profile->pendidikan_asal)); ?>" required>
                    <label for="pendidikan_asal">Pendidikan Asal</label>
                </div>
                </div>
                <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                    <textarea class="form-control h-px-50" placeholder="Alamat lengkap" name="alamat" id="alamat" style="height: 100px" required><?php echo e(old('alamat', $profile->alamat)); ?></textarea>
                    <label for="alamat">Alamat</label>
                </div>
                </div>
                <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                    <input type="text" class="form-control" name="no_telepon" id="no_telepon" value="<?php echo e(old('no_telepon', $profile->no_telepon)); ?>">
                    <label for="no_telepon">No Telepon</label>
                </div>
                </div>
                <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                    <input type="email" class="form-control" name="email" id="email" value="<?php echo e(old('email', $profile->email)); ?>">
                    <label for="email">Email</label>
                </div>
                </div>
                <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                    <input type="text" class="form-control" name="nama_ayah" id="nama_ayah" value="<?php echo e(old('nama_ayah', $profile->nama_ayah)); ?>" required>
                    <label for="nama_ayah">Nama Ayah</label>
                </div>
                </div>
                <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                    <input type="text" class="form-control" name="pekerjaan_ayah" id="pekerjaan_ayah" value="<?php echo e(old('pekerjaan_ayah', $profile->pekerjaan_ayah)); ?>" required>
                    <label for="pekerjaan_ayah">Pekerjaan Ayah</label>
                </div>
                </div>
                <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                    <input type="text" class="form-control" name="no_hp_ayah" id="no_hp_ayah" value="<?php echo e(old('no_hp_ayah', $profile->no_hp_ayah)); ?>" required>
                    <label for="no_hp_ayah">No HP Ayah</label>
                </div>
                </div>
                <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                    <input type="text" class="form-control" name="nama_ibu" id="nama_ibu" value="<?php echo e(old('nama_ibu', $profile->nama_ibu)); ?>" required>
                    <label for="nama_ibu">Nama Ibu</label>
                </div>
                </div>
                <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                    <input type="text" class="form-control" name="pekerjaan_ibu" id="pekerjaan_ibu" value="<?php echo e(old('pekerjaan_ibu', $profile->pekerjaan_ibu)); ?>" required>
                    <label for="pekerjaan_ibu">Pekerjaan Ibu</label>
                </div>
                </div>
                <div class="col-md-6">
                <div class="form-floating form-floating-outline">
                    <input type="text" class="form-control" name="no_hp_ibu" id="no_hp_ibu" value="<?php echo e(old('no_hp_ibu', $profile->no_hp_ibu)); ?>" required>
                    <label for="no_hp_ibu">No HP Ibu</label>
                </div>
                </div>
            </div>
            <div class="mt-6 d-flex justify-content-end gap-2">
                <a href="<?php echo e(route('profile.show')); ?>" class="btn btn-secondary">← Kembali</a>
                <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
            </div>
            </form>
        </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutMaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Kuliah\TA\Project TA\web\SI-Ponpes-Al-ihsan 2\resources\views/Profile/ProfileSantriEdit.blade.php ENDPATH**/ ?>