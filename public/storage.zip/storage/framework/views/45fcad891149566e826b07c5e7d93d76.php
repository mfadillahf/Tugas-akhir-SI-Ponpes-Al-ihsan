

<?php $__env->startSection('title', 'Galeri'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Section: page title -->
    <section class="page-title layer-overlay overlay-dark-9 section-typo-light bg-img-center" style="padding-top: 120px;" data-tm-bg-img="<?php echo e(asset('LandingPage/studypress/images/bg/bg1.jpg')); ?>">
        <div class="container pt-50 pb-50">
            <div class="section-content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="row align-items-center">
                            <div class="col-md-6 text-center text-md-start">
                            <h2 class="title">Galeri Ponpes Al-Ihsan </h2>
                            </div>
                            <div class="col-md-6 text-end">
                            <nav class="breadcrumbs" role="navigation" aria-label="Breadcrumbs">
                                <div class="breadcrumbs">
                                <span><a href="<?php echo e(route('landing')); ?>">Beranda</a></span>
                                <span><i class="fa fa-angle-right mx-2"></i></span>
                                <span class="active">Galeri</span>
                                </div>
                            </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Gallery Grid 3 -->
    <section>
        <div class="container">
            <div class="section-content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="tm-sc-gallery tm-sc-gallery-grid gallery-style1-basic">

                            <!-- Isotope Filter -->
                            <div class="isotope-layout-filter filter-style-4 text-left cat-filter-default text-center" data-link-with="gallery-holder-618422">
                                <a href="#" class="active" data-filter="*">All</a>
                                <?php $__currentLoopData = $kategoriGaleri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="#" data-filter=".katg-<?php echo e($kat->id); ?>"><?php echo e($kat->nama_kategori); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <!-- End Isotope Filter -->

                            <!-- Isotope Gallery Grid -->
                            <div id="gallery-holder-618422" class="isotope-layout grid-3 gutter-15 clearfix lightgallery-lightbox">
                                <div class="isotope-layout-inner">
                                    <?php $__currentLoopData = $galeri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="isotope-item katg-<?php echo e($item->kategori_galeri_id); ?>">
                                            <div class="isotope-item-inner">
                                                <div class="tm-gallery">
                                                    <div class="tm-gallery-inner">
                                                        <div class="thumb">
                                                            <a href="#">
                                                                <img width="672" height="448" src="<?php echo e(asset('storage/galeri/' . $item->foto)); ?>" alt="<?php echo e($item->judul); ?>" />
                                                            </a>
                                                        </div>
                                                        <div class="tm-gallery-content-wrapper">
                                                            <div class="tm-gallery-content">
                                                                <div class="tm-gallery-content-inner">
                                                                    <div class="icons-holder-inner">
                                                                        <div class="styled-icons icon-dark icon-circled icon-theme-colored1">
                                                                            <a class="lightgallery-trigger styled-icons-item"
                                                                                data-exthumbimage="<?php echo e(asset('storage/galeri/' . $item->foto)); ?>"
                                                                                data-src="<?php echo e(asset('storage/galeri/' . $item->foto)); ?>"
                                                                                title="<?php echo e($item->judul); ?>"
                                                                                href="<?php echo e(asset('storage/galeri/' . $item->foto)); ?>">
                                                                                <i class="fa fa-plus"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="title-holder">
                                                                        <h5 class="title"><a href="#"><?php echo e($item->judul); ?></a></h5>
                                                                        <small class="text-muted"><?php echo e($item->kategoriGaleri->nama_kategori ?? '-'); ?></small>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <!-- End Isotope Gallery Grid -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.landing', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Kuliah\TA\Project TA\web\SI-Ponpes-Al-ihsan 2\resources\views/LandingPage/GaleriIndex.blade.php ENDPATH**/ ?>