<?php
    $configData = Helper::appClasses();
?>


<?php $__env->startSection('title', 'Dashboard - Admin'); ?>

<?php $__env->startSection('vendor-style'); ?>
<?php echo app('Illuminate\Foundation\Vite')([
    'resources/assets/vendor/libs/apex-charts/apex-charts.scss',
    'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
    'resources/assets/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.scss',
    'resources/assets/vendor/libs/datatables-checkboxes-jquery/datatables.checkboxes.scss'
    ]); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-style'); ?>
<?php echo app('Illuminate\Foundation\Vite')('resources/assets/vendor/scss/pages/app-logistics-dashboard.scss'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')([
    'resources/assets/vendor/libs/apex-charts/apexcharts.js',
    'resources/assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js'
    ]); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')('resources/assets/js/app-logistics-dashboard.js'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row g-6">
    <!-- Welcome Card -->
    <div class="col-md-12 col-xxl-8">
        <div class="card">
        <div class="d-flex align-items-start row">
            <div class="col-md-6 order-2 order-md-1">
            <div class="card-body">
                <h4 class="card-title mb-4">Selamat Datang, <span class="fw-bold"><?php echo e(auth()->user()->username); ?></span> 👋</h4>
            </div>
            </div>
            <div class="col-md-6 text-center text-md-end order-1 order-md-2">
            <div class="card-body pb-0 px-0 pt-2">
                <img src="<?php echo e(asset('assets/img/illustrations/illustration-john-' . $configData['style'] . '.png')); ?>" height="186" class="scaleX-n1-rtl" alt="Welcome" data-app-light-img="illustrations/illustration-john-light.png" data-app-dark-img="illustrations/illustration-john-dark.png">
            </div>
            </div>
        </div>
        </div>
    </div>

<!-- Statistik Cards -->
<div class="row g-4">
  <div class="col-sm-6 col-lg-3">
    <div class="card card-border-shadow-primary h-100">
      <div class="card-body">
        <div class="d-flex align-items-center mb-2">
          <div class="avatar me-4">
            <span class="avatar-initial rounded-3 bg-label-primary"><i class="ri-group-3-line"></i></span>
          </div>
          <h4 class="mb-0"><?php echo e($jumlahSantri); ?></h4>
        </div>
        <h6 class="mb-0 fw-normal">Jumlah Santri</h6>
      </div>
    </div>
  </div>

  <div class="col-sm-6 col-lg-3">
    <div class="card card-border-shadow-success h-100">
      <div class="card-body">
        <div class="d-flex align-items-center mb-2">
          <div class="avatar me-4">
            <span class="avatar-initial rounded-3 bg-label-success"><i class="ri-user-2-fill"></i></span>
          </div>
          <h4 class="mb-0"><?php echo e($jumlahGuru); ?></h4>
        </div>
        <h6 class="mb-0 fw-normal">Jumlah Guru</h6>
      </div>
    </div>
  </div>

  <div class="col-sm-6 col-lg-3">
    <div class="card card-border-shadow-warning h-100">
      <div class="card-body">
        <div class="d-flex align-items-center mb-2">
          <div class="avatar me-4">
            <span class="avatar-initial rounded-3 bg-label-warning"><i class="ri-user-2-line"></i></span>
          </div>
          <h4 class="mb-0"><?php echo e($jumlahDonatur); ?></h4>
        </div>
        <h6 class="mb-0 fw-normal">Jumlah Donatur</h6>
      </div>
    </div>
  </div>

  <div class="col-sm-6 col-lg-3">
    <div class="card card-border-shadow-danger h-100">
      <div class="card-body">
        <div class="d-flex align-items-center mb-2">
          <div class="avatar me-4">
            <span class="avatar-initial rounded-3 bg-label-danger"><i class="ri-group-line"></i></span>
          </div>
          <h4 class="mb-0"><?php echo e($jumlahPengurus); ?></h4>
        </div>
        <h6 class="mb-0 fw-normal">Jumlah Pengurus</h6>
      </div>
    </div>
  </div>
</div>
</div>
<!-- /Statistik Cards -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutMaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Kuliah\TA\Project TA\web\SI-Ponpes-Al-ihsan 2\resources\views/dashboardadmin.blade.php ENDPATH**/ ?>