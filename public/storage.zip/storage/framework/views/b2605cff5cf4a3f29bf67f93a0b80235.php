

<?php $__env->startSection('title'); ?>
Dashboard Santri
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-style'); ?>
<?php echo app('Illuminate\Foundation\Vite')([
    'resources/assets/vendor/libs/apex-charts/apex-charts.scss'
]); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')([
    'resources/assets/vendor/libs/apex-charts/apexcharts.js'
]); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')('resources/assets/js/app-academy-dashboard.js'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
    <div class="card-body row g-4">
        <div class="col-12">
        <h5 class="mb-2">Selamat Datang,
            <span class="h4 fw-semibold"><?php echo e(auth()->user()->username); ?> 👋🏻</span>
        </h5>

        
        <?php if($santri->status === 'santri'): ?>
            <p class="mb-4 text-muted">Berikut Informasi Data Akademik Anda</p>
            <div class="row g-4">
            
            <div class="col-sm-4">
                <div class="d-flex align-items-center">
                <div class="avatar avatar-lg me-3">
                    <div class="avatar-initial bg-label-primary rounded-3">
                    <img src="<?php echo e(asset('assets/svg/icons/laptop.svg')); ?>" alt="laptop" class="img-fluid" />
                    </div>
                </div>
                <div>
                    <p class="mb-1 fw-medium">Rata-Rata Nilai</p>
                    <h5 class="mb-0 text-primary"><?php echo e($rataRataNilai); ?></h5>
                </div>
                </div>
            </div>

            
            <div class="col-sm-4">
                <div class="d-flex align-items-center">
                <div class="avatar avatar-lg me-3">
                    <div class="avatar-initial bg-label-info rounded-3">
                    <img src="<?php echo e(asset('assets/svg/icons/lightbulb.svg')); ?>" alt="lightbulb" class="img-fluid" />
                    </div>
                </div>
                <div>
                    <p class="mb-1 fw-medium">Jumlah Surah Dihafal</p>
                    <h5 class="mb-0 text-info"><?php echo e($jumlahSurah); ?></h5>
                </div>
                </div>
            </div>

            
            <div class="col-sm-4">
                <div class="d-flex align-items-start">
                <div class="avatar avatar-lg me-3">
                    <div class="avatar-initial bg-label-warning rounded-3">
                    <img src="<?php echo e(asset('assets/svg/icons/check.svg')); ?>" alt="check" class="img-fluid" />
                    </div>
                </div>
                <div>
                    <p class="mb-1 fw-medium">Mata Pelajaran Dinilai</p>
                    <?php if($mapelList->isNotEmpty()): ?>
                    <ul class="mb-0 list-unstyled small">
                        <?php $__currentLoopData = $mapelList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mapel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="text-warning"><?php echo e($mapel); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php else: ?>
                    <span class="text-muted small">Belum ada mapel</span>
                    <?php endif; ?>
                </div>
                </div>
            </div>
            </div>
        <?php else: ?>
            
            <p class="text-muted mb-4">Status kamu saat ini <strong><?php echo e(ucfirst($santri->status)); ?> Santri</strong>.</p>
            <div class="alert alert-info">
            Data akademik hanya dapat diakses setelah status kamu resmi menjadi <strong>santri aktif</strong>.
            Tunggu informasi lebih lanjut.
            </div>
        <?php endif; ?>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutMaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Kuliah\TA\Project TA\web\SI-Ponpes-Al-ihsan 2\resources\views/dashboardsantri.blade.php ENDPATH**/ ?>