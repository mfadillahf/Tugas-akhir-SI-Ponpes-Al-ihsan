

<?php $__env->startSection('title', 'Edit Galeri'); ?>

<?php $__env->startSection('vendor-style'); ?>
<?php echo app('Illuminate\Foundation\Vite')([
    'resources/assets/vendor/libs/bootstrap-select/bootstrap-select.scss',
    'resources/assets/vendor/libs/select2/select2.scss',
    'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
    'resources/assets/vendor/libs/tagify/tagify.scss',
    'resources/assets/vendor/libs/@form-validation/form-validation.scss'
]); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')([
    'resources/assets/vendor/libs/select2/select2.js',
    'resources/assets/vendor/libs/bootstrap-select/bootstrap-select.js',
    'resources/assets/vendor/libs/moment/moment.js',
    'resources/assets/vendor/libs/flatpickr/flatpickr.js',
    'resources/assets/vendor/libs/tagify/tagify.js',
    'resources/assets/vendor/libs/@form-validation/popular.js',
    'resources/assets/vendor/libs/@form-validation/bootstrap5.js',
    'resources/assets/vendor/libs/@form-validation/auto-focus.js'
]); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/assets/js/form-validation-galeri.js']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main class="app-main">
    <div class="col-12">
        <div class="card shadow-sm">
            <div class="card-body">

                
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form id="formGaleriEdit" action="<?php echo e(route('galeri.update', $galeri->id_galeri)); ?>" method="POST" enctype="multipart/form-data" class="row g-4 needs-validation">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="col-12">
                        <h4 class="fw-bold">Edit Galeri</h4>
                    </div>

                    
                    <div class="col-12">
                        <h6>1. Kategori</h6>
                        <hr />
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating form-floating-outline">
                            <select name="kategori_galeri_id" id="kategori_galeri_id" class="form-select" required>
                                <option value="" disabled>-- Pilih Kategori --</option>
                                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($kat->id); ?>" <?php echo e(old('kategori_galeri_id', $galeri->kategori_galeri_id) == $kat->id ? 'selected' : ''); ?>>
                                        <?php echo e($kat->nama_kategori); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    
                    <div class="col-12">
                        <h6 class="mt-2">2. Deskripsi</h6>
                        <hr />
                    </div>
                    <div class="col-md-12">
                        <label for="deskripsi" class="form-label">Deskripsi</label>
                        <textarea class="form-control" name="deskripsi" id="deskripsi" rows="4" required><?php echo e(old('deskripsi', $galeri->deskripsi)); ?></textarea>
                    </div>

                    
                    <div class="col-12">
                        <h6 class="mt-2">3. Informasi Tambahan</h6>
                        <hr />
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating form-floating-outline">
                            <input type="date" id="tanggal" name="tanggal" class="form-control" value="<?php echo e(old('tanggal', $galeri->tanggal)); ?>" required>
                            <label for="tanggal">Tanggal</label>
                        </div>
                    </div>

                    
                    <div class="col-12">
                        <h6 class="mt-2">4. Foto</h6>
                        <hr />
                    </div>
                    <div class="col-md-12">
                        <div class="form-floating form-floating-outline">
                            <input type="file" id="foto" name="foto" class="form-control" accept="image/*">
                            <label for="foto">Ganti Foto (Opsional)</label>
                        </div>

                        <?php if($galeri->foto): ?>
                            <div class="mt-3">
                                <p>Foto Saat Ini:</p>
                                <img src="<?php echo e(asset('storage/galeri/' . $galeri->foto)); ?>" alt="Foto Galeri" class="img-fluid" style="max-width: 200px;">
                            </div>
                        <?php endif; ?>
                    </div>

                    
                    <div class="col-12 d-flex justify-content-end gap-2 mt-3">
                        <a href="<?php echo e(route('galeri.index')); ?>" class="btn btn-secondary">← Kembali</a>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </form>

            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutMaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Kuliah\TA\Project TA\web\SI-Ponpes-Al-ihsan 2\resources\views/sistem/galeriedit.blade.php ENDPATH**/ ?>