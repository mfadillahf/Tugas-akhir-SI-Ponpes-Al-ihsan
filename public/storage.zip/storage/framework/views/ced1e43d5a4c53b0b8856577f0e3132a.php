

<?php $__env->startSection('title', 'Data Kepengurusan'); ?>

<!-- Vendor Styles -->
<?php $__env->startSection('vendor-style'); ?>
<?php echo app('Illuminate\Foundation\Vite')([
    'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
    'resources/assets/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.scss',
    'resources/assets/vendor/libs/datatables-checkboxes-jquery/datatables.checkboxes.scss',
    'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
    'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
    'resources/assets/vendor/libs/datatables-rowgroup-bs5/rowgroup.bootstrap5.scss',
    'resources/assets/vendor/libs/@form-validation/form-validation.scss',
    'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss'
]); ?>
<?php $__env->stopSection(); ?>

<!-- Vendor Scripts -->
<?php $__env->startSection('vendor-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')([
    'resources/assets/vendor/libs/jquery/jquery.js',
    'resources/assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js',
    'resources/assets/vendor/libs/moment/moment.js',
    'resources/assets/vendor/libs/flatpickr/flatpickr.js',
    'resources/assets/vendor/libs/@form-validation/popular.js',
    'resources/assets/vendor/libs/@form-validation/bootstrap5.js',
    'resources/assets/vendor/libs/@form-validation/auto-focus.js',
    'resources/assets/vendor/libs/sweetalert2/sweetalert2.js'
]); ?>
<?php $__env->stopSection(); ?>

<!-- Page Scripts -->
<?php $__env->startSection('page-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/assets/js/tables-datatables-kepengurusan.js']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<meta name="flash-success" content="<?php echo e(session('success')); ?>">
<meta name="flash-error" content="<?php echo e(session('error')); ?>">

<main class="app-main">
    <div class="app-content">
        <div class="container-fluid">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
            <h3 class="card-title mb-0">Data Kepengurusan</h3>
            <?php if (\Illuminate\Support\Facades\Blade::check('role', 'admin')): ?>
            <a href="<?php echo e(route('kepengurusan.create')); ?>" class="btn btn-primary btn-sm">
                <i class="ri-add-line"></i> Tambah Kepengurusan
            </a>
            <?php endif; ?>
            </div>

            <div class="card-datatable table-responsive pt-0">
            <table class="datatables-basic table table-bordered">
                <thead class="table-light">
                <tr>
                    <th>No</th>
                    <th>Foto</th>
                    <th>Nama</th>
                    <th>Jabatan</th>
                    <th>Mulai</th>
                    <th>Akhir</th>
                    <th>Aksi</th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $kepengurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($key + 1); ?></td>
                    <td>
                    <?php if($k->foto): ?>
                        <img src="<?php echo e(asset('storage/kepengurusan/' . $k->foto)); ?>" alt="Foto Kepengurusan" class="img-thumbnail" style="max-width: 80px; height: auto;">
                    <?php else: ?>
                        <span class="text-muted">-</span>
                    <?php endif; ?>
                    </td>
                    <td><?php echo e($k->nama); ?></td>
                    <td><?php echo e($k->jabatan); ?></td>
                    <td><?php echo e($k->mulai); ?></td>
                    <td><?php echo e($k->akhir); ?></td>
                    <td>
                    <button type="button" class="btn btn-info btn-sm" data-id="<?php echo e($k->id_kepengurusan); ?>" data-bs-toggle="modal" data-bs-target="#detailModal">
                        <i class="ri-information-line"></i>
                    </button>
                    <?php if (\Illuminate\Support\Facades\Blade::check('role', 'admin')): ?>
                    <a href="<?php echo e(route('kepengurusan.edit', $k->id_kepengurusan)); ?>" class="btn btn-warning btn-sm">
                        <i class="ri-edit-line"></i>
                    </a>
                    <form action="<?php echo e(route('kepengurusan.destroy', $k->id_kepengurusan)); ?>" method="POST" style="display:inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="button" class="btn btn-danger btn-sm btn-delete" data-id="<?php echo e($k->id_kepengurusan); ?>">
                        <i class="ri-delete-bin-line"></i>
                        </button>
                    </form>
                    <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
                </tbody>
            </table>
            </div>
        </div>
        </div>
    </div>
</main>


<div class="modal fade" id="detailModal" tabindex="-1" aria-labelledby="modalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="modalLabel">Detail Kepengurusan</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body" id="modalBody"></div>
        <div class="modal-footer">
            <button class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
        </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutMaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Kuliah\TA\Project TA\web\SI-Ponpes-Al-ihsan 2\resources\views/Kepengurusan/Kepengurusan.blade.php ENDPATH**/ ?>