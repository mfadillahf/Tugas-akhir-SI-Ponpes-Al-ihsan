<?php use Illuminate\Support\Facades\Auth; ?>


<?php $__env->startSection('title', 'Data Nilai Santri'); ?>

<!-- Vendor Styles -->
<?php $__env->startSection('vendor-style'); ?>
<?php echo app('Illuminate\Foundation\Vite')([
    'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
    'resources/assets/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.scss',
    'resources/assets/vendor/libs/datatables-checkboxes-jquery/datatables.checkboxes.scss',
    'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
    'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
    'resources/assets/vendor/libs/datatables-rowgroup-bs5/rowgroup.bootstrap5.scss',
    'resources/assets/vendor/libs/@form-validation/form-validation.scss',
    'resources/assets/vendor/libs/select2/select2.scss',
    'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss'
]); ?>
<?php $__env->stopSection(); ?>

<!-- Vendor Scripts -->
<?php $__env->startSection('vendor-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')([
    'resources/assets/vendor/libs/jquery/jquery.js',
    'resources/assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js',
    'resources/assets/vendor/libs/moment/moment.js',
    'resources/assets/vendor/libs/flatpickr/flatpickr.js',
    'resources/assets/vendor/libs/@form-validation/popular.js',
    'resources/assets/vendor/libs/@form-validation/bootstrap5.js',
    'resources/assets/vendor/libs/@form-validation/auto-focus.js',
    'resources/assets/vendor/libs/select2/select2.js',
    'resources/assets/vendor/libs/sweetalert2/sweetalert2.js'
]); ?>
<?php $__env->stopSection(); ?>

<!-- Page Scripts -->
<?php $__env->startSection('page-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/assets/js/tables-datatables-nilai.js']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<meta name="flash-success" content="<?php echo e(session('success')); ?>">
<meta name="flash-error" content="<?php echo e(session('error')); ?>">
<meta name="user-role" content="<?php echo e(Auth::user()->getRoleNames()->first()); ?>">

<main class="app-main">
    <div class="app-content">
        <div class="container-fluid">

            
            <?php if (\Illuminate\Support\Facades\Blade::check('role', 'guru')): ?>
            <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h3 class="card-title mb-0">Filter Nilai</h3>
                <button class="btn btn-sm btn-outline-primary" type="button" data-bs-toggle="collapse" data-bs-target="#filterCollapse" aria-expanded="false" aria-controls="filterCollapse">
                <i class="ri-filter-line me-1"></i> Filter
                </button>
            </div>
            <div class="collapse" id="filterCollapse">
                <div class="card-body border-top">
                <form method="GET" action="<?php echo e(route('nilai.index')); ?>">
                    <div class="row g-3 align-items-end">
                    <div class="col-md-4">
                        <label class="form-label">Kelas</label>
                        <select name="id_kelas" class="form-select select2">
                        <option value="">Semua Kelas</option>
                        <?php $__currentLoopData = $kelasList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($kelas->id_kelas); ?>" <?php echo e(request('id_kelas') == $kelas->id_kelas ? 'selected' : ''); ?>>
                            <?php echo e($kelas->nama_kelas); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Mapel</label>
                        <select name="id_mapel" class="form-select select2">
                        <option value="">Semua Mapel</option>
                        <?php $__currentLoopData = $mapelList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mapel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($mapel->id_mapel); ?>" <?php echo e(request('id_mapel') == $mapel->id_mapel ? 'selected' : ''); ?>>
                            <?php echo e($mapel->mapel); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <div class="row g-2">
                        <div class="col">
                            <label class="form-label">Tahun Ajaran</label>
                            <input type="text" name="tahun_ajaran" class="form-control" value="<?php echo e(request('tahun_ajaran')); ?>" placeholder="2024/2025">
                        </div>
                        <div class="col-auto d-flex align-items-end gap-1">
                            <button class="btn btn-primary" type="submit">
                            <i class="ri-search-line"></i>
                            </button>
                            <a href="<?php echo e(route('nilai.index')); ?>" class="btn btn-outline-secondary">
                            <i class="ri-refresh-line"></i>
                            </a>
                        </div>
                        </div>
                    </div>
                    </div>
                </form>
                </div>
            </div>
            </div>
            <?php endif; ?>



            
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
                    <h3 class="card-title mb-0">Daftar Nilai Santri</h3>
                    <?php if (\Illuminate\Support\Facades\Blade::check('role', 'guru')): ?>
                    <a href="<?php echo e(route('nilai.create')); ?>" class="btn btn-primary btn-sm">
                        <i class="ri-add-line"></i> Tambah Nilai
                    </a>
                    <?php endif; ?>
                </div>

                <div class="card-datatable table-responsive pt-0">
                    <table class="table table-bordered datatables-basic">
                        <thead class="table-light">
                            <tr>
                                <th>No</th>
                                <?php if (\Illuminate\Support\Facades\Blade::check('role', 'guru')): ?>
                                    <th>Nama Santri</th>
                                    <th>Kelas</th>
                                <?php endif; ?>
                                <th>Mapel</th>
                                <th>Nilai</th>
                                <th>Tahun Ajaran</th>
                                <?php if (\Illuminate\Support\Facades\Blade::check('role', 'guru')): ?>
                                <th>Aksi</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $nilaiList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $nl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e(($nilaiList->firstItem() ?? 0) + $key); ?></td>
                                <?php if (\Illuminate\Support\Facades\Blade::check('role', 'guru')): ?>
                                    <td><?php echo e($nl->santri->nama_lengkap); ?></td>
                                    <td><?php echo e($nl->santri->kelas->nama_kelas ?? '-'); ?></td>
                                <?php endif; ?>
                                <td><?php echo e($nl->mapel->mapel ?? '-'); ?></td>
                                <td><?php echo e($nl->nilai); ?></td>
                                <td><?php echo e($nl->tahun_ajaran); ?></td>
                                <?php if (\Illuminate\Support\Facades\Blade::check('role', 'guru')): ?>
                                <td>
                                    <a href="<?php echo e(route('nilai.edit', $nl->id_nilai)); ?>" class="btn btn-warning btn-sm">
                                        <i class="ri-edit-line"></i>
                                    </a>
                                    <form action="<?php echo e(route('nilai.destroy', $nl->id_nilai)); ?>" method="POST" style="display:inline-block;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="button" class="btn btn-danger btn-sm btn-delete-nilai" data-id="<?php echo e($nl->id_nilai); ?>">
                                            <i class="ri-delete-bin-line"></i>
                                        </button>
                                    </form>
                                </td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutMaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Kuliah\TA\Project TA\web\SI-Ponpes-Al-ihsan 2\resources\views/nilai/nilai.blade.php ENDPATH**/ ?>