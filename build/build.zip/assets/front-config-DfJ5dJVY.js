window.assetsPath=document.documentElement.getAttribute("data-assets-path");window.templateName=document.documentElement.getAttribute("data-template");window.rtlSupport=!0;
