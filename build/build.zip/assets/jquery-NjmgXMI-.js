import{g as r}from"./_commonjsHelpers-D6-XlEtG.js";import{r as o}from"./jquery-BQXThELV.js";var e=o();const a=r(e);export{a as j};
