import{j as r}from"./jquery-NjmgXMI-.js";import"./_commonjsHelpers-D6-XlEtG.js";import"./jquery-BQXThELV.js";try{window.jQuery=window.$=r}catch{}
