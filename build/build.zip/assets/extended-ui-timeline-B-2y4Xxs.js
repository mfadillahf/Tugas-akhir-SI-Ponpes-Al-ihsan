(function(){AOS.init({disable:function(){return window.innerWidth<1024},once:!0})})();
