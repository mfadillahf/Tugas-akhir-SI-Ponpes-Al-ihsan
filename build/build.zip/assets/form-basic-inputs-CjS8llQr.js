(function(){const e=document.getElementById("defaultCheck2");e.indeterminate=!0})();
