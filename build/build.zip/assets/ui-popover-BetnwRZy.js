(function(){[].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]')).map(function(o){return new bootstrap.Popover(o)})})();
